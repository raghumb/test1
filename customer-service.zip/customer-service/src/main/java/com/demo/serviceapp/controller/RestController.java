package com.demo.serviceapp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class RestController extends BaseController{
    @GetMapping("health")
    String health(){    	
        return "Ping from Rest controller";
    }
}
