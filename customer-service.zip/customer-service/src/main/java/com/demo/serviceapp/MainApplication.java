package com.demo.serviceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import zipkin.server.EnableZipkinServer;
import org.springframework.cloud.netflix.eureka.server.EnableDiscoveryClient;

@SpringBootApplication
@EnableZipkinServer
@EnableDiscoveryClient 
public class MainApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainApplication.class, args);
	}

}
